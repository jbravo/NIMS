export class CatDeviceTypeModel {
  deviceTypeid: number; // id thiết bị
  deviceTypeCode: string; // mã loại cáp
  vendorId: number; // hãng sản xuất;
  note: string; // ghi chú
  createTime: string; // thời gian tạo bản ghi;
  updateTime: string; // thời gian cập nhập gần nhất;
  rowStatus: number; // trạng thái ban ghi
}
