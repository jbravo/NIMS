export class CatItemModel {
  itemId: number;
  itemCode: string;
  itemName: string;
  categoryId: number;
  note: number;
  createTime: string;
  updateTime: string;
  rowStatus: number;
}
