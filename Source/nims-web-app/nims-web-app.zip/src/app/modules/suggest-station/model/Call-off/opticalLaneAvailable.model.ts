export class OpticalLaneAvailableModel {
  laneCode: string; // mã tuyến
  lengthHang: number; // chiều dài treo tái sử dụng  theo
  lengthBury: number; // chiều dài trôn tái sử dụng theo
}
