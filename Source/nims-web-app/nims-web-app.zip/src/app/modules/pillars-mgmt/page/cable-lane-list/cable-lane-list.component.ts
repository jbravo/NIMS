import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cable-lane-list',
  templateUrl: './cable-lane-list.component.html',
  styleUrls: ['./cable-lane-list.component.css']
})
export class CableLaneListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
