import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cable-lanes',
  templateUrl: './cable-lanes.component.html',
  styleUrls: ['./cable-lanes.component.css']
})
export class CableLanesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
