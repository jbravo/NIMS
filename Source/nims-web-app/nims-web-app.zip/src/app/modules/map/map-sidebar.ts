export class MapSidebar {
  keyInputInjector?: string[];
  valueInputInjector?: Object[];
}
