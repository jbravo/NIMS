import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'autocomplete-select-obj',
  templateUrl: './autocomplete-select-obj.component.html',
  styleUrls: ['./autocomplete-select-obj.component.css']
})
export class AutocompleteSelectObjComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
