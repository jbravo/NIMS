import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'work-flows-search',
  templateUrl: './work-flows-search.component.html',
  styles: []
})
export class WorkFlowsSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
