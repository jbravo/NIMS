import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'work-flows-form',
  templateUrl: './work-flows-form.component.html',
  styles: []
})
export class WorkFlowsFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
