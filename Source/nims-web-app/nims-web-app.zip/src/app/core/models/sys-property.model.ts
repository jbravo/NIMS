export class SysPropertyBean {
  propertyId: number;
  code: string;
  name: string;
  menuId: number;
  startDate: string;
  endDate: string;
  createdBy: string;
  tableName: string;
  columnName: string;
}
