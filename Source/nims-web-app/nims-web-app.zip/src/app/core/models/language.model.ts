export class LanguageBean {
  tableName?: string;
  columnName?: string;
  objectId?: number;
  languageId?: number;
  name?: string;
  languageCode?: string;
  value?: string;
  sortOrder?: number;
}
