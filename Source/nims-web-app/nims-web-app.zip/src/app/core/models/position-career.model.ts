export class PositionCareerBean {
  majorCareerId: number;
  lineOrgId: number;
  code: string;
  name: string;
  isUsed: number;
  nationId: number;
  sortOrder: number;
  managementType: number;
  effectiveDate: number;
  expiredDate: number;
}
