export class LabourContractTypeBean {
    labourContractTypeId: number;
    code: string;
    name: string;
    status: number;
    nationId: number;
}