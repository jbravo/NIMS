export class Pagination {
    first: number;
    rows: number;
    sortOrder: number;
    sortField: string;
    totalRecords: number;
}
