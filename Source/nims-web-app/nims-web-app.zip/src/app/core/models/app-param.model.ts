export class AppParam {
  parId: number;
  parCode: string;
  parName: string;
  parValue: string;
  parType: string;
  description: string;
  parOrder: number;
  isActive: number;
}
