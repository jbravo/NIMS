import { Pagination } from './pagination.model';

export class WorkProcessModel extends Pagination {
    partyMembersId: number;
  }
