export class AllowanceTypeBean {
    allowanceTypeId: number;
    code: string;
    name: string;
    description: string;
  }
