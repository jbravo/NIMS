import { Pagination } from './pagination.model';

export class OganizationController extends Pagination {
    name: string;
    code: string;
    parentId:number;
}