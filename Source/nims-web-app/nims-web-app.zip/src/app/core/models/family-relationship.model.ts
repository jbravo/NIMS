export class FamilyRelationship {

}
