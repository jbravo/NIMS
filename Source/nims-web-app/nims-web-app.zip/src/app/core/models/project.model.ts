export class Project {
    link: string;
    title: string;
}
