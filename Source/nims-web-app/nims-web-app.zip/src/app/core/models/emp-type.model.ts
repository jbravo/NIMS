export class EmpTypeBean {
  empTypeId: number;
  code: string;
  name: string;
  hasSoldierInfo: number;
  hasLabourContractInfo: number;
  empTypeOrder: number;
  isUsed: number;
  isDisplay: number;
  nationId: number;
}
