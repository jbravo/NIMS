export class SysCatBean {
  sysCatId: number;
  code: string;
  name: string;
  status: number;
  sortOrder: number;
  description: string;
}
